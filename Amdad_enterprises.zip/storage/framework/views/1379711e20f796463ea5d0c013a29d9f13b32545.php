
<?php $__env->startSection('title', 'Product Details'); ?>
<?php $__env->startSection('main_content'); ?>

<!-- Page Header Start -->
<div class="container-fluid page-header wow fadeIn" data-wow-delay="0.1s">
    <div class="container">
        <h1 class="mb-3 animated slideInDown text-white">Products Details</h1>
        
    </div>
</div>
<!-- Page Header End -->

<!-- Product Details Section Start -->
<div class="container-xxl py-5">
    <div class="container">
        <div class = "card-wrapper">
            <div class="row">
                <!-- card left -->
                <div class="col-lg-6 col-md-6">
                    <div class ="product-imgs">
                        <div class ="img-display">
                            <div class ="img-showcase">
                                
                                <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <img src="<?php echo e(asset($item->other_img)); ?>" alt="shoe image">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="img-select">
                            
                            <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="img-item">
                                <a href="#" data-id="<?php echo e($key + 1); ?>">
                                    <img src="<?php echo e(asset($item->other_img)); ?>" alt="shoe image">
                                </a>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>

                <!-- card right -->
                <div class="col-lg-6 col-md-6">
                    <div class = "product-content">
                        <h2 class = "product-title"><?php echo e($product->name); ?></h2>
                        <div class = "product-price">
                            <!-- <p class = "last-price">Old Price: <span>$257.00</span></p> -->
                            
                        </div>
            
                        <div class = "product-detail">
                            <h2>about this item: </h2>
                            <p><?php echo $product->description; ?></p>
                        </div>
            
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Product End -->

<!-- Related Product Section -->
<div class="container-xxl py-4 related_section">
    <div class="container">
        <div class="row g-0 gx-5 align-items-end">
            <div class="col-lg-6">
                <div class="section-header text-start mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 500px;">
                    <h1 class="display-5">Related Products</h1>
                </div>
            </div>
            
        </div>

        <div class="tab-content">
            <div class="tab-pane fade show p-0 active">
                <div class="row g-4">
                    <?php $__currentLoopData = $related_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                    <div class="col-xl-3 col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="product-item">
                            <div class="position-relative bg-light overflow-hidden">
                                <img class="img-fluid w-100" src="<?php echo e(asset($item->image)); ?>" alt="">
                                <?php if($item->is_new == 1): ?>
                                    <div class="bg-secondary rounded text-white position-absolute start-0 top-0 px-2">New</div>
                                <?php else: ?>
                                <?php endif; ?>
                            </div>
                            <div class="text-center p-2">
                                <a class="d-block h5 mb-2" href="<?php echo e(route('product.single', $item->slug)); ?>"><?php echo e($item->name); ?></a>
                                
                            </div>
                            <div class="d-flex border-top">
                                <small class="w-100 text-center py-2">
                                    <a class="text-body" href="<?php echo e(route('product.single', $item->slug)); ?>"><i class="fa fa-eye text-primary me-2"></i>Visit Product</a>
                                </small>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Amdad_enterprise\resources\views/pages/product_single.blade.php ENDPATH**/ ?>