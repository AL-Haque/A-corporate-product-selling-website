<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
    <meta charset="utf-8">
    <title><?php echo e($content->com_name); ?> | <?php echo $__env->yieldContent('title'); ?></title>
    <meta name="csrf-token" id="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="<?php echo e(asset($content->logo)); ?>" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500&amp;family=Lora:wght@600;700&amp;display=swap" rel="stylesheet"> 

    <!-- Icon Font Stylesheet -->
    <link href="<?php echo e(asset('website/css/lightbox.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('website/css/all.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('website/css/bootstrap-icons.css')); ?>" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="<?php echo e(asset('website/lib/animate/animate.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('website/lib/owlcarousel/assets/owl.carousel.min.css')); ?>" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="<?php echo e(asset('website/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="<?php echo e(asset('website/css/style.css')); ?>" rel="stylesheet">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border text-primary" role="status"></div>
    </div>
    <!-- Spinner End -->


    <!-- Navbar Start -->
    <?php echo $__env->make('partials.web_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Navbar End -->

    
    <?php echo $__env->yieldContent('main_content'); ?>

    <!-- Footer Start -->
    <?php echo $__env->make('partials.web_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Footer End -->

    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square rounded-circle back-to-top"><i class="fa fa-arrow-up"></i></a>

    <!-- JavaScript Libraries -->
    <script src="<?php echo e(asset('website/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('website/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('website/lib/wow/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('website/js/lightbox.js')); ?>"></script>
    <script src="<?php echo e(asset('website/lib/easing/easing.min.js')); ?>"></script>
    <script src="<?php echo e(asset('website/lib/waypoints/waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('website/lib/owlcarousel/owl.carousel.min.js')); ?>"></script>

    <!-- Template Javascript -->
    <script src="<?php echo e(asset('website/js/main.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('web_script'); ?>
</body>

</html><?php /**PATH /home/amdad4terprise1/public_html/resources/views/layouts/web_master.blade.php ENDPATH**/ ?>