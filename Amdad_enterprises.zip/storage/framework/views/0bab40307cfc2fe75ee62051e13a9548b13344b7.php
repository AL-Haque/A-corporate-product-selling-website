
<?php $__env->startSection('title', 'About'); ?>
<?php $__env->startSection('main_content'); ?>

<!-- Page Header Start -->
<div class="container-fluid page-header wow fadeIn" data-wow-delay="0.1s">
    <div class="container">
        <h1 class="mb-3 animated slideInDown text-white">About Us</h1>
    </div>
</div>
<!-- Page Header End -->

<!-- About Start -->
<div class="container-xxl py-4">
    <div class="container">
        <div class="row g-5 align-items-center">
            <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                <div class="about-img position-relative overflow-hidden p-4 pe-0">
                    <img class="img-fluid w-100" src="<?php echo e(asset($about->image)); ?>">
                </div>
            </div>
            <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
                <h1 class="display-5 mb-4"><?php echo e($about->title); ?></h1>
                <p class="mb-4"><?php echo $about->description; ?></p>
                
            </div>
        </div>
    </div>
</div>
<!-- About End -->
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/amdad4terprise1/public_html/resources/views/pages/about.blade.php ENDPATH**/ ?>