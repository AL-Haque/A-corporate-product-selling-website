
<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('main_content'); ?>

<!-- Carousel Start -->
<?php echo $__env->make('partials.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Carousel End -->

<!-- Our Product Section Start -->
<div class="container-xxl py-3 our_product_sec">
    <div class="container">
        <div class="text-center mx-auto mb-4 product_head" style="max-width: 500px;">
            <h5>Our Products</h5>
            <h1 class="display-5 mb-2">At a Glance</h1>
        </div>

        <div class="row g-5 align-items-center">
            <?php $__currentLoopData = $home_firstproduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-6">
                <div class="cate-img">
                    <img src="<?php echo e(asset($item->image)); ?>" alt="Avatar" class="image">
                    <div class="cat_content">
                        <div class="cat_text">
                            <i class="fas fa-globe"></i>
                            <h4><?php echo e($item->name); ?></h4>
                        </div>
                    </div>

                    <div class="overlay">
                        <div class="text">
                            <i class="fas fa-globe"></i>
                            <h4><?php echo e($item->name); ?></h4>
                            <p><?php echo Str::limit($item->description, 60); ?></p>
                            <a href="<?php echo e(route('product.single', $item->slug)); ?>">Visite Product</a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
    </div>
</div>
<!-- Our Product Section End -->

<!-- Product Section Start -->
<div class="container-xxl product_section">
    <div class="container">
       
        <div class="row">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
            <div class="col-xs-6 col-sm-4 col-md-3 i">
                <div class="c text-center">
                    <div class="wrap">
                        <img src="<?php echo e(asset($item->image)); ?>" alt="#" width="270" height="270" class="img-responsive">
                        <div class="info">
                            <h4 class="position"><?php echo e($item->name); ?></h4>
                            <a href="<?php echo e(route('product.single', $item->slug)); ?>">Visit Products</a>
                        </div>
                    </div>
                    
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<!-- Product End -->

<!-- Brand Section Start -->
<div class="container-xxl py-4 brand_sec">
    <div class="container">
        <div class="text-center mx-auto mb-4 brand_head" style="max-width: 500px;">
            <h5>Brands</h5>
            <h1 class="display-5 mb-2">Some of the Products Brand</h1>
        </div>

        <div class="row">
            <?php $__currentLoopData = $home_brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
            <div class="col-lg-2 col-md-6 mb-3">
                <div class="brand_img">
                    <a href="<?php echo e(route('brand.products', $item->id)); ?>"><img src="<?php echo e(asset($item->image)); ?>" class="img-fluid" alt=""></a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="row">
            <div class="col">
                <div class="brand_btn d-flex justify-content-end">
                    <a href="<?php echo e(route('all.brand')); ?>">View All</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Brand Section End -->

<!-- Photo Gallery Start -->

<!-- Photo Gallery End -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/amdad4terprise1/public_html/resources/views/pages/web_index.blade.php ENDPATH**/ ?>