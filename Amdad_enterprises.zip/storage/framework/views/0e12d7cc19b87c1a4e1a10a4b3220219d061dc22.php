<div class="container-fluid fixed-top px-0 wow fadeIn" data-wow-delay="0.1s">
    <div class="top-bar row gx-0 d-none d-lg-flex">
        <div class="col-lg-7 px-5">
            <a href="<?php echo e(route('index')); ?>" class="navbar-brand">
                <div class="d-flex justify-content-between">
                    <h5 class="fw-bold text-black mt-4"><?php echo e($content->com_name); ?></h5>
                    <img src="<?php echo e(asset($content->logo)); ?>" alt="">
                </div>
            </a>
        </div>
        <div class="col-lg-5 px-5 text-end mt-4">
            <a class="text-body ms-3" href="<?php echo e($content->facebook); ?>" target="_blank"><i class="fab fa-facebook-f text-white"></i></a>
            <a class="text-body ms-3" href="<?php echo e($content->twitter); ?>" target="_blank"><i class="fab fa-twitter text-white"></i></a>
            <a class="text-body ms-3" href="<?php echo e($content->linkedin); ?>" target="_blank"><i class="fab fa-linkedin-in text-white"></i></a>
            <a class="text-body ms-3" href="<?php echo e($content->youtube); ?>" target="_blank"><i class="fab fa-youtube text-white"></i></a>
        </div>
    </div>

    <div class="main-menu d-flex justify-content-between">
        <nav>
            <ul>
                <li><a href="<?php echo e(route('index')); ?>"><i class="fa fa-home" aria-hidden="true"></i> Home</a></li>
                <li><a href="<?php echo e(route('about')); ?>">About Us</a></li>
                <li><a href="<?php echo e(route('products')); ?>"> Our Products <i class="fa fa-caret-right" aria-hidden="true"></i></a>
                    <ul class="sub-menu me-auto">
                        <?php
                            $side_category = App\Models\Category::where('parent_id', 0)->with('children')->orderBy('name', 'asc')->get();
                        ?>

                        <?php $__currentLoopData = $side_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('category.products', $item->id)); ?>"><?php echo e($item->name); ?>

                            <?php if($item->children->count() > 0): ?> 
                            <i class="fa fa-caret-right" aria-hidden="true"></i>
                            <?php endif; ?>
                        </a>
                        <?php if($item->children->count() > 0): ?> 
                            <ul class="child-menu">
                                <?php $__currentLoopData = $item->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><a href="<?php echo e(route('category.products', $child->id)); ?>"><?php echo e($child->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </li>
                <li><a href="<?php echo e(route('management')); ?>">Managements</a></li>
                <li><a href="<?php echo e(route('gallery')); ?>">Photo Gallery</a></li>
                <li><a href="<?php echo e(route('contact')); ?>">Contact Us</a></li>
            </ul>
        </nav>

        <form action="<?php echo e(route('search.product')); ?>" method="GET" class="d-flex align-items-center align-self-center me-5">
            <input name="search" id="search" class="form-control shadow-none" type="search" placeholder="Search">
            <button class="btn btn-outline-success shadow-none" type="submit"><i class="fas fa-search"></i></button>
        </form>
    </div>

 
</div><?php /**PATH /home/amdad4terprise1/public_html/resources/views/partials/web_header.blade.php ENDPATH**/ ?>