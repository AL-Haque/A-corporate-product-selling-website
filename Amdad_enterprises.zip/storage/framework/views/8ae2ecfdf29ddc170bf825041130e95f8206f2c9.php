
<?php $__env->startSection('title', 'Products'); ?>
<?php $__env->startSection('main_content'); ?>

<!-- Page Header Start -->
<div class="container-fluid page-header wow fadeIn" data-wow-delay="0.1s">
    <div class="container">
        <h1 class="mb-3 animated slideInDown text-white">Products</h1>
    </div>
</div>
<!-- Page Header End -->


<!-- Product Start -->
<div class="container-xxl py-4 product_pagesection">
    <div class="container-fluid">
        
        <div class="tab-content">
            <div class="tab-pane fade show p-0 active">
                <div class="row g-4">
                    <div class="col-lg-3">
                        <div class="category_left">
                            <h4>Product Categories</h4>
                            <ul>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><i class="fas fa-angle-right"></i> <a href="<?php echo e(route('category.products', $item->id)); ?>"><?php echo e($item->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>

                    <div class="col-lg-9">
                        <div class="row">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <div class="col-xl-3 col-lg-4 col-md-6 wow fadeInUp mb-3" data-wow-delay="0.1s">
                                <div class="product-item">
                                    <div class="position-relative bg-light overflow-hidden">
                                        <img class="img-fluid w-100" src="<?php echo e(asset($item->image)); ?>" alt="">
                                        <?php if($item->is_new == 1): ?> 
                                        <div class="bg-secondary rounded text-white position-absolute start-0 top-0 py-1 px-2">
                                            New
                                        </div>
                                        <?php else: ?>
                                        <?php endif; ?>
                                    </div>
                                    <div class="text-center p-2 product_title">
                                        <a class="d-block mb-2" href="<?php echo e(route('product.single', $item->slug)); ?>"><?php echo e(Str::limit($item->name, 20)); ?></a>
                                        
                                        
                                    </div>
                                    <div class="d-flex border-top">
                                        <small class="w-100 text-center py-3">
                                            <a class="text-body" href="<?php echo e(route('product.single', $item->slug)); ?>">Visite Product</a>
                                        </small>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-12 text-center wow fadeInUp" data-wow-delay="0.1s">
                                <?php echo e($products->links()); ?>

                                
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Product End -->

 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/amdad4terprise1/public_html/resources/views/pages/products.blade.php ENDPATH**/ ?>