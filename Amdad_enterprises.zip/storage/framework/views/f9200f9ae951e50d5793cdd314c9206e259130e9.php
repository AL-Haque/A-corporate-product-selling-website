<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('main_content'); ?>

<!-- Carousel Start -->
<?php echo $__env->make('partials.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Carousel End -->

<!-- Our Product Section Start -->

<section>
    <div class="container">
        <div class="row" style="padding-bottom:80px; ">
            <h3 style="color: brown; padding-top: 50px;  border-bottom: 2px solid brown;">Top product</h3>
            <?php $__currentLoopData = $home_firstproduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-2" style="padding-top: 40px">
                <div class="card center">

                    <a href="<?php echo e(route('product.single', $item->slug)); ?>">
                    <div class="card-body" >
                        <img src="<?php echo e(asset($item->image)); ?>"
                            style=" border:1px solid rgb(243, 235, 235);border-radius: 50%; height:170px; width: 170px;">
                        <!-- <p style="background:brown; color: white;">Product Name(Model)</p> -->
                    </div>
                </a>
                    <div class="name" style="height: 125px; width:194px;font-size:10px;box-shadow: 0 6px 20px 0 rgba(0,0,0,.15);">
                        <p style="text-align: center; font-size:15px; font-weight:500; color: brown; background-color: #fff;"><?php echo e($item->name); ?></p>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
    </div>
    <!-- </div> -->
</section>


 <section>

        <div class="row " style="  background-color: 	#033047; padding-bottom: 50px;  padding-left:40px;padding-right:20px">
            <div class="head" style="padding-top:30px;padding-bottom: 30px;">
                <h2 style="color:#fff ;border-bottom:2px solid #fff; border-radius: 10px;">Shopping with Category
                    Product</h2>
            </div>
            <div class="row row-cols-5">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


            <div class="col" style="padding-bottom:60px">
                <div class="product" >
                    <img src="<?php echo e(asset($item->image)); ?>" alt="Avatar" class="image">
                    <p style=" padding:1rem; text-align: justify; background-color: brown;
                     height:120px; border-bottom-left-radius: 10px; border-bottom-right-radius: 10px; color: white;">
                        <?php echo e($item->name); ?></p>
                    <div class="overlay" >
                        <h5
                            style="text-align: center; color:white; padding-top: 2rem;padding-left: 2rem; padding-right: 2rem;font-size:1rem   ">
                           <?php echo e($item->name); ?>

                        </h5>
                        

                        <div class="button center" style="border-radius: 5px"> <a href="<?php echo e(route('category.products',$item->id)); ?>"><button type="button"> Product Details</button></a> </div>
                    </div>

                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        </div>


    </section>





<!-- Our Product Section End -->

<!-- Product Section Start -->





<!-- Product End -->

<!-- Brand Section Start -->
<div class="container-xxl py-4 brand_sec">
    <div class="container">
        <div class="text-center mx-auto mb-4 brand_head" style="max-width: 500px;">
            <h5>Brands</h5>
            <h1 class="display-5 mb-2">Some of the Products Brand</h1>
        </div>

        <div class="row">
            <?php $__currentLoopData = $home_brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-2 col-md-6 mb-3">
                <div class="brand_img">
                    <a href="<?php echo e(route('brand.products', $item->id)); ?>"><img src="<?php echo e(asset($item->image)); ?>" class="img-fluid" alt=""></a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="row">
            <div class="col">
                <div class="brand_btn d-flex justify-content-end">
                    <a href="<?php echo e(route('all.brand')); ?>">View All</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Brand Section End -->

<!-- Photo Gallery Start -->

<!-- Photo Gallery End -->

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.web_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Amdad_enterprise\resources\views/pages/web_index.blade.php ENDPATH**/ ?>