<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Software | <?php echo $__env->yieldContent('title'); ?></title>
        <link href="<?php echo e(asset($content->logo)); ?>" rel="icon">
        <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet" />

        <link href="<?php echo e(asset('css/toastr.min.css')); ?>" rel="stylesheet" />
        <!-- Sweetalert -->
        <script src="<?php echo e(asset('js/sweetalert.js')); ?>" type="text/javascript"></script>
        <link rel="stylesheet" href="<?php echo e(asset('css/sweetalert.css')); ?>" />
        <?php echo $__env->yieldPushContent('admin-css'); ?>
    </head>
    <body class="sb-nav-fixed">
        
        <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div id="layoutSidenav">
            
            <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div id="layoutSidenav_content">

                <?php echo $__env->yieldContent('main-content'); ?> 
                
                <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <!-- Modal -->
            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Change Password</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                aria-label="Close"></button>
                        </div>
                        <form action="<?php echo e(route('password.change')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="modal-body">
                                <label for="">Old Password</label>
                                <input type="password" name="old_password" class="form-control mb-1 shadow-none"
                                    placeholder="Enter Old Password" required>
                                <label for="">New Password</label>
                                <input type="password" class="form-control shadow-none" name="password"
                                    placeholder="Enter New password" required>
                            </div>
                            <div class="modal-footer">
                                <button type="reset" class="btn btn-secondary">Reset</button>
                                <button type="submit" class="btn btn-primary shadow-none">Save changes</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            
            </div>
        </div>
        <script src="<?php echo e(asset('js/jquery-3.6.0.min.js')); ?>"></script>
        <script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
        <script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>" crossorigin="anonymous"></script>
        <script src=" <?php echo e(asset('js/all.min.js')); ?>" crossorigin="anonymous"></script>
        <script src="<?php echo e(asset('js/simple-datatables@latest.js')); ?>" crossorigin="anonymous"></script>
        <script src="<?php echo e(asset('js/datatables-simple-demo.js')); ?>"></script>
        <script src="//cdn.ckeditor.com/4.19.0/basic/ckeditor.js"></script>
        <script src="<?php echo e(asset('js/toastr.min.js')); ?>"></script>

        <script>
            <?php if(Session::has('message')): ?>
                var type = "<?php echo e(Session::get('alert-type', 'info')); ?>"
                switch (type) {
                    case 'info':
                        toastr.info(" <?php echo e(Session::get('message')); ?> ");
                        break;
    
                    case 'success':
                        toastr.success(" <?php echo e(Session::get('message')); ?> ");
                        break;
    
                    case 'warning':
                        toastr.warning(" <?php echo e(Session::get('message')); ?> ");
                        break;
    
                    case 'error':
                        toastr.error(" <?php echo e(Session::get('message')); ?> ");
                        break;
                }
            <?php endif; ?>
        </script>

        
        <script type="text/javascript">
            setInterval(function() {
                var currentTime = new Date();
                var currentHours = currentTime.getHours();
                var currentMinutes = currentTime.getMinutes();
                var currentSeconds = currentTime.getSeconds();
                currentMinutes = (currentMinutes < 10 ? "0" : "") + currentMinutes;
                currentSeconds = (currentSeconds < 10 ? "0" : "") + currentSeconds;
                var timeOfDay = currentHours < 12 ? "AM" : "PM";
                currentHours = currentHours > 12 ? currentHours - 12 : currentHours;
                currentHours = currentHours == 0 ? 12 : currentHours;
                var currentTimeString = currentHours + ":" + currentMinutes + ":" + currentSeconds + " " + timeOfDay;
                document.getElementById("timer").innerHTML = currentTimeString;
            }, 1000);
        </script>

        <!-- Sweet Alert Delete Post method -->
    <script type="text/javascript">
        $(document).ready(function() {

            $(document).on("click", "#delete", function(e) {
                e.preventDefault();

                var actionTo = $(this).attr("href");
                var token = $(this).attr("data-token");
                var id = $(this).attr("data-id");

                swal({
                        title: "Are You Sure?",
                        type: "success",
                        showCancelButton: true,
                        confirmButtonClass: "btn-success",
                        confirmButtonText: "Yes",
                        cancelButtonText: "No",
                        closeOnConfirm: false,
                        closeOnCancel: false,
                    },
                    function(isConfirm) {
                        if (isConfirm) {
                            $.ajax({
                                url: actionTo,
                                type: "post",
                                data: {
                                    id: id,
                                    _token: token
                                },
                                success: function(res) {
                                    // console.log(res);
                                    if (res.success) {
                                        swal({
                                                title: "Deleted!",
                                                type: "success",
                                            },
                                            function(isConfirm) {
                                                if (isConfirm) {
                                                    $("." + id).fadeOut();
                                                }
                                            }
                                        );

                                    }
                                },
                            });
                        } else {
                            swal("Cancelled", "", "error");
                        }
                    }
                );
                return false;
            });
        });
    </script>

        <?php echo $__env->yieldPushContent('scripts'); ?>

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\Amdad_enterprise\resources\views/layouts/master.blade.php ENDPATH**/ ?>